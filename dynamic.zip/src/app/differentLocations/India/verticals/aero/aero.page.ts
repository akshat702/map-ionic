import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aero',
  templateUrl: './aero.page.html',
  styleUrls: ['./aero.page.scss'],
})
export class AeroPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
