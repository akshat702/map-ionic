import { Component, OnInit } from '@angular/core';
import { Router, RouterEvent } from '@angular/router';

@Component({
  selector: 'app-all-verticals',
  templateUrl: './all-verticals.page.html',
  styleUrls: ['./all-verticals.page.scss'],
})
export class AllVerticalsPage implements OnInit {

  pages = [
    {
      title: 'Aero Engines',
      url: '/India/aero'
    },
    {
      title: 'Auto',
      url: '/India/auto'
    }
  ];

  selectedPath = '';

  constructor(private router: Router) {
    this.router.events.subscribe((event: RouterEvent) => {
      if (event && event.url) {
        this.selectedPath = event.url;
      }
    });
  }

  ngOnInit() {
  }

}
