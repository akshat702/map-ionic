import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kawasaki',
  templateUrl: './kawasaki.page.html',
  styleUrls: ['./kawasaki.page.scss'],
})
export class KawasakiPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
