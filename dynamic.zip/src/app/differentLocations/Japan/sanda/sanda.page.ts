import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sanda',
  templateUrl: './sanda.page.html',
  styleUrls: ['./sanda.page.scss'],
})
export class SandaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
