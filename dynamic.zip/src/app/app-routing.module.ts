import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: ':country', loadChildren: './india-indus/india-indus.module#IndiaIndusPageModule' },
  { path: ':country/:industry', loadChildren: './all-services/all-services.module#AllServicesPageModule' },


  // { path: 'banglore', loadChildren: './differentLocations/India/bangalore/bangalore.module#BangalorePageModule' },
  // { path: 'aero', loadChildren: './differentLocations/India/verticals/aero/aero.module#AeroPageModule' },
  // { path: 'auto', loadChildren: './differentLocations/India/verticals/auto/auto.module#AutoPageModule' },
  { path: 'India', loadChildren: './differentLocations/India/all-verticals/all-verticals.module#AllVerticalsPageModule' },
  { path: 'aero-engine', loadChildren: './services/aero-engine/aero-engine.module#AeroEnginePageModule' },
  { path: 'aero-struct', loadChildren: './services/aero-struct/aero-struct.module#AeroStructPageModule' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
