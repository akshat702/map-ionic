import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AlmDataService {

  private almdata = {
    "country": [
      "India",
      "Spain",
      "US",
      "Italy",
      'Germany'
    ],
    "India": {
      "Industries": [
        "Hi-Tech",
        "Aero Engines"
      ],
      "Hi-Tech": {
        "services": [
          "Design and Developenet",
          "After Market Services"
        ],
        "Design and Developenet": [
          {
            "Name": "Shihab",
            "Phone": "91",
            "Email": "s@quest-global.com",
            "Role": "TSL"
          },
          {
            "Name": "Akshat",
            "Phone": "91",
            "Email": "s@quest-global.com",
            "Role": "ISL"
          }
        ]
      }
    }
  };

  constructor() { }

  getAlmData() {
    return this.almdata;
  }

  getIndustries(country) {
    return this.almdata[country].Industries;
  }

  getService(country, industry) {
    return this.almdata[country][industry].services;
  }
}
