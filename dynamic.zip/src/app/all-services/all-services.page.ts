import { Component, OnInit } from '@angular/core';
import { AlmDataService } from './../alm-data.service';
import { Router, RouterEvent } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-all-services',
  templateUrl: './all-services.page.html',
  styleUrls: ['./all-services.page.scss'],
})
export class AllServicesPage implements OnInit {

country: string;
industry: string;
services: [];

  selectedPath = '';

  constructor(private router: Router, private route: ActivatedRoute, public almData: AlmDataService  ) {
    this.router.events.subscribe((event: RouterEvent) => {
      if (event) {
        // this.selectedPath = event.url;
        console.log("hi",event)
      }
    });
  }

  // myFunction(p){

  // }

  ngOnInit() {
    this.country = this.route.snapshot.paramMap.get('country');
    this.industry = this.route.snapshot.paramMap.get('industry');
    console.log(this.country, "dfsfsf", this.industry)
    this.services = this.almData.getService(this.country, this.industry);
    console.log("I am service", this.services);

  }

}
