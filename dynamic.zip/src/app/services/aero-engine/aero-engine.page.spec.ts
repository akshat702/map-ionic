import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AeroEnginePage } from './aero-engine.page';

describe('AeroEnginePage', () => {
  let component: AeroEnginePage;
  let fixture: ComponentFixture<AeroEnginePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AeroEnginePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AeroEnginePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
