import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aero-engine',
  templateUrl: './aero-engine.page.html',
  styleUrls: ['./aero-engine.page.scss'],
})
export class AeroEnginePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
