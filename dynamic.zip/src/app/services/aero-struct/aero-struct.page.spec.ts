import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AeroStructPage } from './aero-struct.page';

describe('AeroStructPage', () => {
  let component: AeroStructPage;
  let fixture: ComponentFixture<AeroStructPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AeroStructPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AeroStructPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
