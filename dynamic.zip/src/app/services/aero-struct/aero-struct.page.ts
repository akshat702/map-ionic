import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aero-struct',
  templateUrl: './aero-struct.page.html',
  styleUrls: ['./aero-struct.page.scss'],
})
export class AeroStructPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
