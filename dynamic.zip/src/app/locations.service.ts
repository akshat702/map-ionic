import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocationsService {

  private locationData = [
    {
      latitude: 20.5937,
      longitude: 78.9629,
      name: 'QuEST India',
      country: 'India'
    },
    {
      latitude: 55.3781,
      longitude: 3.4360,
      name: 'QuEST UK',
    },
    {
      latitude: 40.4637,
      longitude: 3.7492,
      name: 'QuEST Spain',
    },
    {
      latitude: 41.8719,
      longitude: 12.5674,
      name: 'QuEST Italy',
    },
    {
      latitude: 51.1657,
      longitude: 10.4515,
      name: 'QuEST Germany',
    },
    {
      latitude: 54.5260,
      longitude: 105.2551,
      name: 'QuEST North America',
    }
  ];

  constructor() { }

  getLocation() {
    return this.locationData;
  }
}
