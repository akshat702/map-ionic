import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndiaIndusPage } from './india-indus.page';

describe('IndiaIndusPage', () => {
  let component: IndiaIndusPage;
  let fixture: ComponentFixture<IndiaIndusPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndiaIndusPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndiaIndusPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
