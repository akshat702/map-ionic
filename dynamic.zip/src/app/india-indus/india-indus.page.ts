import { AlmDataService } from './../alm-data.service';
import { Component, OnInit } from '@angular/core';
import { NavComponent } from '@ionic/core';
import { NavController } from '@ionic/angular';
import { Routes } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-india-indus',
  templateUrl: './india-indus.page.html',
  styleUrls: ['./india-indus.page.scss'],
})
export class IndiaIndusPage implements OnInit {

  country: string;
  alm_Data = {};
  industry = [];

  constructor(public navCtrl: NavController,
            private route: ActivatedRoute,
            public almData: AlmDataService) { }

  onChoose(industry) {
    console.log('I am clicked', industry);
    this.navCtrl.navigateForward(`${this.country}/${industry}`);
  }
  ngOnInit() {
    this.country = this.route.snapshot.paramMap.get('country');
    console.log(this.country);
    this.industry = this.almData.getIndustries(this.country);
    console.log("i am industry", this.industry);
  }
}
