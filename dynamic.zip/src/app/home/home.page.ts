import { LocationsService } from './../locations.service';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { LoadingController } from '@ionic/angular';

declare var google;

let infowindow: any;

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  mapRef = null;
  locations = [];

  constructor(
    private geolocation: Geolocation,
    private loadingCtrl: LoadingController,
    private locationSer: LocationsService
  ) {

  }

  ngOnInit() {
    this.loadMap();
    this.locations = this.locationSer.getLocation();
  }

  async loadMap() {
    const loading = await this.loadingCtrl.create();
    loading.present();
    const myLatLng = await this.getLocation();
    console.log(myLatLng);
    const mapEle: HTMLElement = document.getElementById('map');
    this.mapRef = new google.maps.Map(mapEle, {
      center: myLatLng,
      zoom: 3
    });

    infowindow = new google.maps.InfoWindow({});

    google.maps.event
      .addListenerOnce(this.mapRef, 'idle', () => {
        loading.dismiss();
        this.addMarker(this.locations);
      });
  }

  private addMarker(markerLocation) {
    for (let locationMark of markerLocation) {
      const loc = { lat: locationMark.latitude, lng: locationMark.longitude };
      console.log(loc);

      locationMark = new google.maps.Marker({
        position: loc,
        map: this.mapRef,
        title: locationMark.name,
        country: locationMark.country,
        address: locationMark.address
      });

      google.maps.event.addListener(locationMark, 'click', function () {
        console.log('I am in ', locationMark.title);
        infowindow.setContent(
          `
         <h3>${locationMark.title}</h3>
         <h5>${locationMark.address}</h5>
         <br> <a href="/${locationMark.country}">Know more</a>
        `);
        infowindow.open(this.mapRef, this);
      });
    }
  }

  private async getLocation() {
    const rta = await this.geolocation.getCurrentPosition();
    return {
      lat: rta.coords.latitude,
      lng: rta.coords.longitude
    };
  }
}