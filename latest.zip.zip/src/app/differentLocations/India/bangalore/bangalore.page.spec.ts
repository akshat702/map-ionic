import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BangalorePage } from './bangalore.page';

describe('BangalorePage', () => {
  let component: BangalorePage;
  let fixture: ComponentFixture<BangalorePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BangalorePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BangalorePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
