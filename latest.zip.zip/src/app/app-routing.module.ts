import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'banglore', loadChildren: './differentLocations/India/bangalore/bangalore.module#BangalorePageModule' },
  { path: 'kawasaki', loadChildren: './differentLocations/Japan/kawasaki/kawasaki.module#KawasakiPageModule' },
  { path: 'sanda', loadChildren: './differentLocations/Japan/sanda/sanda.module#SandaPageModule' },
  // { path: 'aero', loadChildren: './differentLocations/India/verticals/aero/aero.module#AeroPageModule' },
  // { path: 'auto', loadChildren: './differentLocations/India/verticals/auto/auto.module#AutoPageModule' },
  { path: 'India', loadChildren: './differentLocations/India/all-verticals/all-verticals.module#AllVerticalsPageModule' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
