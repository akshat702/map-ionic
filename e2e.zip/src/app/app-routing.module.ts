import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'QuEST Bangalore', loadChildren: './differentLocations/India/bangalore/bangalore.module#BangalorePageModule' },
  { path: 'belgaum', loadChildren: './differentLocations/India/belgaum/belgaum.module#BelgaumPageModule' },
  { path: 'chennai', loadChildren: './differentLocations/India/chennai/chennai.module#ChennaiPageModule' },
  { path: 'bhubaneswar', loadChildren: './differentLocations/India/bhubaneswar/bhubaneswar.module#BhubaneswarPageModule' },
  { path: 'kawasaki', loadChildren: './differentLocations/Japan/kawasaki/kawasaki.module#KawasakiPageModule' },
  { path: 'sanda', loadChildren: './differentLocations/Japan/sanda/sanda.module#SandaPageModule' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
