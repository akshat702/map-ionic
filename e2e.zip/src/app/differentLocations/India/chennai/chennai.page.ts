import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chennai',
  templateUrl: './chennai.page.html',
  styleUrls: ['./chennai.page.scss'],
})
export class ChennaiPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
