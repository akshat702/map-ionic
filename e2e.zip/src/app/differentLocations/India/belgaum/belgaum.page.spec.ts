import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BelgaumPage } from './belgaum.page';

describe('BelgaumPage', () => {
  let component: BelgaumPage;
  let fixture: ComponentFixture<BelgaumPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BelgaumPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BelgaumPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
