import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-belgaum',
  templateUrl: './belgaum.page.html',
  styleUrls: ['./belgaum.page.scss'],
})
export class BelgaumPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
