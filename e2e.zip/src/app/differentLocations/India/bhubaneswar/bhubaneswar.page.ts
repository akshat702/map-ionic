import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bhubaneswar',
  templateUrl: './bhubaneswar.page.html',
  styleUrls: ['./bhubaneswar.page.scss'],
})
export class BhubaneswarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
