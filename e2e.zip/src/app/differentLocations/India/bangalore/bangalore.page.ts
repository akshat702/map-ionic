import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bangalore',
  templateUrl: './bangalore.page.html',
  styleUrls: ['./bangalore.page.scss'],
})
export class BangalorePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
