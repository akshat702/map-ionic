import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SandaPage } from './sanda.page';

describe('SandaPage', () => {
  let component: SandaPage;
  let fixture: ComponentFixture<SandaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SandaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SandaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
