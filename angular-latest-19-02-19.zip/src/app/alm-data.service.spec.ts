import { TestBed } from '@angular/core/testing';

import { AlmDataService } from './alm-data.service';

describe('AlmDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AlmDataService = TestBed.get(AlmDataService);
    expect(service).toBeTruthy();
  });
});
