import { Injectable } from '@angular/core';
// import JSONData from './test.json';

@Injectable({
  providedIn: 'root'
})
export class AlmDataService {

  private almdata = {
    "country": [
        "UK",
        "Spain",
        "Italy",
        "Germany",
        "India_APAC",
        "NorthAmerica"
    ],
    "UK": {
        "Industries": [
            "Aero Engines",
            "Aero Structures & Systems",
            "Auto",
            "Hi-tech",
            "Medical Devices",
            "Oil & Gas",
            "Power",
            "Rail"
        ],
        "Aero Engines": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murali Mohan B",
                    "Phone": "",
                    "Email": "muralimohan.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Aero Structures & Systems": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Auto": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Sangeeth Kumar S",
                    "Phone": "",
                    "Email": "sangeeth.kumar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        
        "Hi-Tech": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Mubarak A R",
                    "Phone": "",
                    "Email": "mubarak.ar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vishnudas Pushpangadan",
                    "Phone": "",
                    "Email": "vishnudas.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
                
        "Medical Devices": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satish Kumar",
                    "Phone": "",
                    "Email": "Satish.Kumar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satish Kumar",
                    "Phone": "",
                    "Email": "Satish.Kumar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
                
        "Oil & Gas": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Manoj Vivek",
                    "Phone": "",
                    "Email": "manoj.vivek@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Power": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B ",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Manoj Vivek",
                    "Phone": "",
                    "Email": "manoj.vivek@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Rail": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Gangadhar B",
                    "Phone": "",
                    "Email": "gangadhar.bali@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B ",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B ",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        }

    },
    "Spain": {
        "Industries": [
            "Aero Engines",
            "Aero Structures & Systems",
            "Auto",
            "Hi-tech",
            "Medical Devices",
            "Oil & Gas",
            "Power",
            "Rail"
        ],
        "Aero Engines": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murali Mohan B",
                    "Phone": "",
                    "Email": "muralimohan.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Aero Structures & Systems": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Auto": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Sangeeth Kumar S",
                    "Phone": "",
                    "Email": "sangeeth.kumar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        
        "Hi-Tech": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Mubarak A R",
                    "Phone": "",
                    "Email": "mubarak.ar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vishnudas Pushpangadan",
                    "Phone": "",
                    "Email": "vishnudas.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
                
        "Medical Devices": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satish Kumar",
                    "Phone": "",
                    "Email": "Satish.Kumar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satish Kumar",
                    "Phone": "",
                    "Email": "Satish.Kumar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
                
        "Oil & Gas": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Manoj Vivek",
                    "Phone": "",
                    "Email": "manoj.vivek@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Power": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B ",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Manoj Vivek",
                    "Phone": "",
                    "Email": "manoj.vivek@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },
        "Rail": {
            "services": [
                "After Market Services",
                "Design and Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"

            ],
            "After Market Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design and Development": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Gangadhar B",
                    "Phone": "",
                    "Email": "gangadhar.bali@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B ",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B ",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering": [
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        }

    },
    "Italy": {
            "Industries": [
                "Aero Engines",
                "Aero Structures & Systems",
                "Auto",
                "Hi-tech",
                "Medical Devices",
                "Oil & Gas",
                "Power",
                "Rail"
            ],
            "Aero Engines": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murali Mohan B",
                        "Phone": "",
                        "Email": "muralimohan.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
            "Aero Structures & Systems": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satya Iyengar",
                        "Phone": "",
                        "Email": "satya.iyengar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satya Iyengar",
                        "Phone": "",
                        "Email": "satya.iyengar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satya Iyengar",
                        "Phone": "",
                        "Email": "satya.iyengar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
            "Auto": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Sangeeth Kumar S",
                        "Phone": "",
                        "Email": "sangeeth.kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
            
            "Hi-Tech": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Mubarak A R",
                        "Phone": "",
                        "Email": "mubarak.ar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vishnudas Pushpangadan",
                        "Phone": "",
                        "Email": "vishnudas.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
                    
            "Medical Devices": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satish Kumar",
                        "Phone": "",
                        "Email": "Satish.Kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satish Kumar",
                        "Phone": "",
                        "Email": "Satish.Kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
                    
            "Oil & Gas": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Manoj Vivek",
                        "Phone": "",
                        "Email": "manoj.vivek@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
            "Power": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B ",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Manoj Vivek",
                        "Phone": "",
                        "Email": "manoj.vivek@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
            "Rail": {
                "services": [
                    "After Market Services",
                    "Design and Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
    
                ],
                "After Market Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design and Development": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Gangadhar B",
                        "Phone": "",
                        "Email": "gangadhar.bali@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B ",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B ",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            }
    
     },
    "Germany": {
            "Industries": [
                "Aero Engines",
                "Aero Structures & Systems",
                "Auto",
                "Hi-tech",
                "Medical Devices",
                "Oil & Gas",
                "Power",
                "Rail"
            ],
            "Aero Engines": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murali Mohan B",
                        "Phone": "",
                        "Email": "muralimohan.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
    
            },
    
            "Aero Structures & Systems": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satya Iyengar",
                        "Phone": "",
                        "Email": "satya.iyengar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satya Iyengar",
                        "Phone": "",
                        "Email": "satya.iyengar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Satya Iyengar",
                        "Phone": "",
                        "Email": "satya.iyengar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Auto": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                       
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Sangeeth Kumar S",
                        "Phone": "",
                        "Email": "sangeeth.kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Hi-tech": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Mubarak A R",
                        "Phone": "",
                        "Email": "mubarak.ar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vishnudas Pushpangadan",
                        "Phone": "",
                        "Email": "vishnudas.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Medical Devices": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satish Kumar",
                        "Phone": "",
                        "Email": "Satish.Kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Satish Kumar",
                        "Phone": "",
                        "Email": "Satish.Kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
            
    
            "Oil & Gas": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Manoj Vivek",
                        "Phone": "",
                        "Email": "manoj.vivek@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Power": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Manoj Vivek",
                        "Phone": "",
                        "Email": "manoj.vivek@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Rail": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Gangadhar B",
                        "Phone": "",
                        "Email": "gangadhar.bali@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            }
     },
     "India_APAC": {
        "Industries": [
             "Aero Engines",
             "Aero Structures & Systems",
             "Auto",
             "Hi-tech",
             "Medical Devices",
             "Oil & Gas",
             "Power",
             "Rail"
        ],
        "Aero Engines": {
            "services": [
                "Aftermarket Services",
                "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services": [
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murali Mohan B",
                    "Phone": "",
                    "Email": "muralimohan.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
    
            ],
            "Detail Engineering":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },




        "Aero Structures & Systems": {
            "services": [
                "Aftermarket Services",
               "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services": [
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Satya Iyengar",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
                
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
               
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
              
                {
                    "Name": "Brian Leona",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },





        "Auto": {
            "services": [
                "Aftermarket Services",
               "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services": [
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "satya.iyengar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
              
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
                
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Sangeeth Kumar S",
                    "Phone": "",
                    "Email": "sangeeth.kumar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },




        "Hi-tech": {
            "services": [
                "Aftermarket Services",
                "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services": [
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
               {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering":[
              
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
              
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
              
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
              
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Mubarak A R",
                    "Phone": "",
                    "Email": "mubarak.ar@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
              
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vishnudas Pushpangadan",
                    "Phone": "",
                    "Email": "vishnudas.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
               
                {
                    "Name": "Gopakumar Vasavan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Krish Kupathil",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },



        "Medical Devices": {
            "services": [
                "Aftermarket Services",
                "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services": [
               
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
              
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering":[
              
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
              
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
               
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"   
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
              
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
              
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
               
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
            
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
              
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
               
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
               
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan V V",
                    "Phone": "",
                    "Email": "murugan.vv@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
               
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajkin G",
                    "Phone": "",
                    "Email": "rajkin.g@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
               
                {
                    "Name": "Pratheep PS",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },


        
        "Oil & Gas": {
            "services": [
                "Aftermarket Services",
                "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services": [
                
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering":[
              
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
              
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Rajesh Kumar P",
                    "Phone": "",
                    "Email": "rajeshkumar.p@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
             
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Manoj Vivek",
                    "Phone": "",
                    "Email": "manoj.vivek@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
               
                {
                    "Name": "Senthil Kumar Rajagopalan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Steve Gerber",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },


        "Power": {
            "services": [
                "Aftermarket Services",
                "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services ": [
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
              
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"   
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Vijay Anand",
                    "Phone": "",
                    "Email": "vijay.r@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
                
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
           
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
             
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
              
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Manoj Vivek",
                    "Phone": "",
                    "Email": "manoj.vivek@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
               
                {
                    "Name": "PK Mohan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        },



        "Rail": {
            "services": [
                "Aftermarket Services",
                "Design & Development",
                "Detail Engineering",
                "Engineering Analysis",
                "Engineering Analytics",
                "Manufacturing Engineering",
                "Technical Data Services",
                "Supply Chain Solutions",
                "Technical Services (Mechanical)",
                "Digital Tech Services",
                "Electronics & Embedded Systems",
                "Engineering Software (Automation)",
                "Engineering Software (Product)",
                "Instrumentation & Electrical Engineering"
            ],
            "Aftermarket Services": [
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Design & Development":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ashok P Kuduva",
                    "Phone": "",
                    "Email": "ashok.kuduva@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Detail Engineering":[
              
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Kumar Varadarajan",
                    "Phone": "",
                    "Email": "kumar.varadarajan@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analysis":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Shivananda K",
                    "Phone": "",
                    "Email": "Shivananda.K@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Analytics":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Manufacturing Engineering":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Gangadhar B",
                    "Phone": "",
                    "Email": "gangadhar.bali@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Data Services":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Venkata Rao",
                    "Phone": "",
                    "Email": "venkata.rao@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Supply Chain Solutions":[
                
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Technical Services (Mechanical)":[
                
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Digital Tech Services":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Ankush Tiwari",
                    "Phone": "",
                    "Email": "ankush.tiwari@mobiliya.com",
                    "Role": "TSL"
                }
            ],
            "Electronics & Embedded Systems":[
             
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Automation)":[
               
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Babu",
                    "Phone": "",
                    "Email": "thandaveshwara.babu@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Engineering Software (Product)":[
                
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Yadukumar B",
                    "Phone": "",
                    "Email": "yadukumar.b@quest-global.com",
                    "Role": "TSL"
                }
            ],
            "Instrumentation & Electrical Engineering":[
                
                {
                    "Name": "Sherry C Kunjachan",
                    "Phone": "",
                    "Email": "",
                    "Role": "IL"
                },
                {
                    "Name": "Berthold Puchta",
                    "Phone": "",
                    "Email": "",
                    "Role": "SIL"
                },
                {
                    "Name": "Murugan Arumugam",
                    "Phone": "",
                    "Email": "murugan.arumugam@quest-global.com",
                    "Role": "TSL"
                }
            ]
        }
    },
    "NorthAmerica": {
            "Industries": [
                "Aero Engines",
                "Aero Structures & Systems",
                "Auto",
                "Hi-tech",
                "Medical Devices",
                "Oil & Gas",
                "Power",
                "Rail"
            ],
            "Aero Engines": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Pete Chenard",
                        "Phone": "",
                        "Email": "peter.chenard@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
    
            },
    
            "Aero Structures & Systems": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rich Nunez",
                        "Phone": "",
                        "Email": "richard.nunez@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Larry Reynolds",
                        "Phone": "",
                        "Email": "larry.reynolds@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Tyler Davis",
                        "Phone": "",
                        "Email": "tyler.davis@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "James Bruns",
                        "Phone": "",
                        "Email": "james.bruns@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Phil Kloos",
                        "Phone": "",
                        "Email": "phil.kloos@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Brian Leona",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Auto": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Sangeeth Kumar S",
                        "Phone": "",
                        "Email": "sangeeth.kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Hi-tech": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Mubarak A R",
                        "Phone": "",
                        "Email": "mubarak.ar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vishnudas Pushpangadan",
                        "Phone": "",
                        "Email": "vishnudas.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Gopakumar Vasavan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Krish Kupathil",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Medical Devices": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Satish Kumar",
                        "Phone": "",
                        "Email": "Satish.Kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Satish Kumar",
                        "Phone": "",
                        "Email": "Satish.Kumar@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Pratheep PS",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
            
    
            "Oil & Gas": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Rajesh Kumar P",
                        "Phone": "",
                        "Email": "rajeshkumar.p@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Manoj Vivek",
                        "Phone": "",
                        "Email": "manoj.vivek@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Senthil Kumar Rajagopalan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Steve Gerber",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Power": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Vijay Anand",
                        "Phone": "",
                        "Email": "vijay.r@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Manoj Vivek",
                        "Phone": "",
                        "Email": "manoj.vivek@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "PK Mohan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            },
    
            "Rail": {
                "services": [
                    "Aftermarket Services",
                    "Design & Development",
                    "Detail Engineering",
                    "Engineering Analysis",
                    "Engineering Analytics",
                    "Manufacturing Engineering",
                    "Technical Data Services",
                    "Supply Chain Solutions",
                    "Technical Services (Mechanical)",
                    "Digital Tech Services",
                    "Electronics & Embedded Systems",
                    "Engineering Software (Automation)",
                    "Engineering Software (Product)",
                    "Instrumentation & Electrical Engineering"
                ],
                "Aftermarket Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Design & Development": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ashok P Kuduva",
                        "Phone": "",
                        "Email": "ashok.kuduva@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Detail Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Kumar Varadarajan",
                        "Phone": "",
                        "Email": "kumar.varadarajan@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analysis": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Shivananda K",
                        "Phone": "",
                        "Email": "Shivananda.K@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Analytics": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Manufacturing Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Gangadhar B",
                        "Phone": "",
                        "Email": "gangadhar.bali@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Data Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Venkata Rao",
                        "Phone": "",
                        "Email": "venkata.rao@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Supply Chain Solutions": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Technical Services (Mechanical)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Alexandra Christy",
                        "Phone": "",
                        "Email": "alexandra.christy@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Digital Tech Services": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Ankush Tiwari",
                        "Phone": "",
                        "Email": "ankush.tiwari@mobiliya.com",
                        "Role": "TSL"
                    }
                ],
                "Electronics & Embedded Systems": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Automation)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Babu",
                        "Phone": "",
                        "Email": "thandaveshwara.babu@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Engineering Software (Product)": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        
                        "Name": "Yadukumar B",
                        "Phone": "",
                        "Email": "yadukumar.b@quest-global.com",
                        "Role": "TSL"
                    }
                ],
                "Instrumentation & Electrical Engineering": [
                    {
                        "Name": "Sherry C Kunjachan",
                        "Phone": "",
                        "Email": "",
                        "Role": "IL"
                    },
                    {
                        "Name": "Berthold Puchta",
                        "Phone": "",
                        "Email": "",
                        "Role": "SIL"
                    },
                    {
                        "Name": "Murugan Arumugam",
                        "Phone": "",
                        "Email": "murugan.arumugam@quest-global.com",
                        "Role": "TSL"
                    }
                ]
            }
     }
}

  constructor() {
    // console.log('Hia....', JSONData);
   }

  getAlmData() {
    return this.almdata;
  }

  getIndustries(country) {
    return this.almdata[country].Industries;
  }

  getService(country, industry) {
    return this.almdata[country][industry].services;
  }

  getServiceDetails(country, industry, details) {
    return this.almdata[country][industry][details];
  }
}
