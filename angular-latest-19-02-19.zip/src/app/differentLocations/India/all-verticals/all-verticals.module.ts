import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { AllVerticalsPage } from './all-verticals.page';

const routes: Routes = [
  {
    path: '',
    component: AllVerticalsPage,
    children: [
      {
        path: 'aero',
        loadChildren: '../verticals/aero/aero.module#AeroPageModule'
      },
      {
        path: 'auto',
        loadChildren: '../verticals/auto/auto.module#AutoPageModule'
      },
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [AllVerticalsPage]
})
export class AllVerticalsPageModule {}
